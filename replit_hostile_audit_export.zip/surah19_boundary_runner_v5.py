#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
surah19_boundary_runner_v5.py
=============================
LCR / SCAR — Danny Scott 2026
Framework  : LCR (Law of Coherent Revelation)
Validator  : scar_validator_v1_0_P27_T2.py

Purpose
-------
Count Surah 19 muqattaat letters under the sealed normalisation pipeline and
emit a validator-compatible boundary file for SCAR determinism checks.

Top-level schema compatibility
------------------------------
This runner emits the six required top-level fields expected by the SCAR
validator boundary schema (ARTEFACT_SCHEMAS in scar_validator_v1_0_P27_T2.py):

    run_id
    sealed_at
    artefact_hashes
    environment
    validator_hash
    manifest_hash

All additional fields are supplementary provenance only (validator ignores them).

Usage
-----
Primary run (produces EXECUTION_BOUNDARY.lock.json):
    python surah19_boundary_runner_v5.py --mode primary

Rerun (produces RERUN_BOUNDARY.lock.json):
    python surah19_boundary_runner_v5.py --mode rerun

Optional explicit root (defaults to script directory):
    python surah19_boundary_runner_v5.py --mode primary --run-dir /path/to/run

Required files in run root
--------------------------
    USETHISQuran-uthmani_FIXED.txt
    manifest.json
    RUN_REPORT.json
    OBSERVED_METRICS.json
    NULL_METRICS.json
    STATISTICS.json
    COMPARISON.json
    FAILURE_SUMMARY.json

CHANGELOG vs v4
---------------
V5-M1  PYTHONHASHSEED captured in environment block.
       Records the hash seed for full environment provenance.
       On Pydroid 3 this is typically unset; recording it removes an
       edge case a hostile auditor could raise about hash randomisation.

V5-M2  corpus_path and manifest_path recorded inside environment block.
       An auditor reading the boundary sees exactly which files were consumed
       without needing to reconstruct the path model independently.

V5-M3  observed_corpus_sha passed explicitly into build_boundary() and stored
       in lcr_provenance alongside corpus_sha256_expected.
       Both expected and observed SHAs now appear side by side in the record.

V5-M4  resolve_run_root() / join_run() separated as named helpers (cleaner
       than inline os.path.join calls scattered through main()).

V5-M5  Type hints added throughout (List, Tuple, Dict).

PACK SHA — CANONICAL AUTHORITY RECORD
--------------------------------------
sealed_pack_sha256 = 308b05b79096103a6569de1f0a8b56c7f178a6d4a8ddc3a3c89fabe0051c5105

Source: PACK_SHA256-12.txt (uploaded directly from project, Danny Scott 2026)
Content: "Version: 1.3 -- canonical frozen -- 11/11 hostile attacks detected"
Sealed:  2026-04-06T22:41:00.235191+00:00

The value 6ab3bb00c2d038d9ee243d72b7445e88d03654395abf259a12907e01be2d7ab3
appears in PACK_SHA256-4.txt from the ChatGPT audit thread and refers to an
earlier intermediate pack version.  It is NOT the canonical frozen value and
must not be substituted here.  Any automated rewrite inserting 6ab3bb is wrong.

OPERATING RULES
---------------
* No re-derivation.
* Strict separation: computed / structural inference / interpretation.
* No synthesis beyond verified data.
* Self-contained; stdlib only (compatible with Pydroid 3).
"""

import argparse
import hashlib
import json
import os
import platform
import re
import sys
import time
import unicodedata
from typing import Dict, List, Tuple

# ============================================================================
# 0.  SEALED CONSTANTS  —  do NOT alter.
# ============================================================================

RUN_ID_PRIMARY = "SURAH19-LCR-001"
RUN_ID_RERUN   = "SURAH19-LCR-001-RERUN"

RUNNER_IDENTITY: Dict[str, object] = {
    "framework":                  "LCR",
    "author":                     "Danny Scott",
    "year":                       2026,
    "validator":                  "scar_validator_v1_0_P27_T2.py",
    # SHA-256 of scar_validator_v1_0_P27_T2.py.
    # The validator checks this against its own self-hashes at init /
    # preflight / post-run (R-PR-09, R-PR-12 fix 5).
    "validator_hash":             "7da40937cfa70524484498be5755e760a8915ab79cc915c5b80e6a884ed2f8f8",
    "corpus_sha256":              "6d80075f2b8f68b501997ab67af85adb3c2ebab4201e635aa9e0c2426f0dea44",
    "scar_schema_authority":      "7ede1e7927bd31df971290a583e259f50b4d85513216aa80dc87f6123575d86f",
    "canonical_authority_doc_sha":"5c80de750a72e5281ad75b37a10c6edaf3ca1bcbb1846c1c11985153cdbddbde",
    # Canonical v1.3 FINAL pack — confirmed from PACK_SHA256-12.txt.
    # DO NOT replace with 6ab3bb — that is an earlier intermediate value.
    "sealed_pack_sha256":         "308b05b79096103a6569de1f0a8b56c7f178a6d4a8ddc3a3c89fabe0051c5105",
    "profile":                    "hostile_audit",
    "null_samples":               100000,
    "seed":                       1337,
    "alpha":                      0.05,
    "fdr":                        "BH",
}

CORPUS_FILENAME   = "USETHISQuran-uthmani_FIXED.txt"
MANIFEST_FILENAME = "manifest.json"

# Six run artefacts whose SHA-256 values populate artefact_hashes.
# Boundary files themselves are excluded — consistent with
# DETERMINISM_EXCLUDED in the validator (R-PR-12).
ARTEFACT_FILES: List[str] = [
    "RUN_REPORT.json",
    "OBSERVED_METRICS.json",
    "NULL_METRICS.json",
    "STATISTICS.json",
    "COMPARISON.json",
    "FAILURE_SUMMARY.json",
]

BOUNDARY_PRIMARY = "EXECUTION_BOUNDARY.lock.json"
BOUNDARY_RERUN   = "RERUN_BOUNDARY.lock.json"

SURAH_NUMBER = 19

# ============================================================================
# 1.  NORMALISATION PIPELINE
#     Sealed: strip_diacritics | strip_tatweel | ة→ه | ى→ي | ئ→ي
# ============================================================================

_DIACRITIC_RE = re.compile(
    r"[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06DC\u06DF-\u06E4"
    r"\u06E7\u06E8\u06EA-\u06ED]"
)
_TATWEEL      = "\u0640"   # ـ  kashida
_TA_MARBUTA   = "\u0629"   # ة
_ALEF_MAQSURA = "\u0649"   # ى
_YA_HAMZA     = "\u0626"   # ئ
_HA           = "\u0647"   # ه
_YA           = "\u064A"   # ي


def normalise(text: str) -> str:
    """Apply the sealed LCR normalisation pipeline to a single string."""
    text = unicodedata.normalize("NFC", text)   # 1. NFC
    text = _DIACRITIC_RE.sub("", text)          # 2. strip diacritics
    text = text.replace(_TATWEEL, "")           # 3. strip tatweel
    text = text.replace(_TA_MARBUTA, _HA)       # 4. ة → ه
    text = text.replace(_ALEF_MAQSURA, _YA)     # 5. ى → ي
    text = text.replace(_YA_HAMZA, _YA)         # 6. ئ → ي
    return text


# ============================================================================
# 2.  MUQATTAAT LETTERS / EXPECTED COUNTS
# ============================================================================

MUQATTAAT_MAP: Dict[str, str] = {
    "kaf": "\u0643",   # ك
    "ha":  "\u0647",   # ه  (post-normalisation: also captures ة)
    "ya":  "\u064A",   # ي  (post-normalisation: also captures ى and ئ)
    "ayn": "\u0639",   # ع
    "sad": "\u0635",   # ص
}

EXPECTED: Dict[str, int] = {
    "kaf":   137,
    "ha":    175,
    "ya":    343,
    "ayn":   117,
    "sad":    26,
    "total": 798,
}

THETA_SEALED   = 1.2
P_VALUE_BOUND  = "< 1e-6"
KAPPA_L_SEALED = 0.1


# ============================================================================
# 3.  HASH UTILITIES
# ============================================================================

def sha256_file(path: str) -> str:
    """Hash a file from disc in binary mode."""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_string(s: str) -> str:
    return sha256_bytes(s.encode("utf-8"))


# ============================================================================
# 4.  PATH MODEL  (V4-P1: all paths anchored to one root)
# ============================================================================

def resolve_run_root(user_run_dir: str = None) -> str:
    """
    Return the absolute run root directory.
    Defaults to the directory containing this script so Pydroid 3 tap-run
    always operates on the correct directory regardless of cwd.
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))
    if user_run_dir:
        return os.path.abspath(user_run_dir)
    return base_dir


def join_run(root: str, name: str) -> str:
    """Resolve a filename within the run root."""
    return os.path.join(root, name)


# ============================================================================
# 5.  CORPUS PARSING  (GAI = line-1)
# ============================================================================

def parse_surah(corpus_path: str, surah: int) -> List[Tuple[int, str]]:
    """Return sorted list of (verse_number, raw_text) for the target surah."""
    verses: List[Tuple[int, str]] = []
    with open(corpus_path, "r", encoding="utf-8") as fh:
        for raw in fh:
            raw = raw.rstrip("\r\n")
            if not raw:
                continue
            parts = raw.split("|", 2)
            if len(parts) < 3:
                continue
            try:
                s = int(parts[0])
                v = int(parts[1])
            except ValueError:
                continue
            if s == surah:
                verses.append((v, parts[2]))
    verses.sort(key=lambda x: x[0])
    return verses


# ============================================================================
# 6.  COUNTING / THETA
# ============================================================================

def count_letters(verses: List[Tuple[int, str]]) -> Dict[str, int]:
    """
    Count muqattaat letters across all normalised verses.
    Input is the single canonical parse — parse_surah() is not called twice.
    """
    counts: Dict[str, int] = {k: 0 for k in MUQATTAAT_MAP}
    for _v, text in verses:
        normed = normalise(text)
        for name, char in MUQATTAAT_MAP.items():
            counts[name] += normed.count(char)
    counts["total"] = sum(counts[k] for k in MUQATTAAT_MAP)
    return counts


def restate_theta(observed_total: int) -> Dict[str, object]:
    """
    Theta is a sealed pre-registered constant from the hostile_audit proof pack.
    Re-states it and confirms the observed total is consistent.
    Does NOT re-run the Monte Carlo simulation.
    """
    return {
        "theta_value":               THETA_SEALED,
        "theta_computation_method":  "sealed_pre_registered_constant",
        "theta_source":              "hostile_audit_proof_pack",
        "null_mean_implied":         EXPECTED["total"] / THETA_SEALED,
        "observed_total":            observed_total,
        "observed_matches_expected": observed_total == EXPECTED["total"],
    }


# ============================================================================
# 7.  ARTEFACT HASHING
# ============================================================================

def hash_artefacts(run_root: str) -> Tuple[Dict[str, str], List[str]]:
    """
    Hash each of the six run artefacts from run_root.
    Returns (hashes_dict, missing_list).
    All paths resolved from run_root — cwd never consulted.
    """
    hashes:  Dict[str, str] = {}
    missing: List[str]      = []
    for name in ARTEFACT_FILES:
        path = join_run(run_root, name)
        if os.path.isfile(path):
            hashes[name] = sha256_file(path)
        else:
            missing.append(name)
    return hashes, missing


# ============================================================================
# 8.  BOUNDARY BUILD / SEAL
# ============================================================================

def build_boundary(
    mode:                str,
    run_root:            str,
    corpus_path:         str,
    manifest_path:       str,
    artefact_hashes:     Dict[str, str],
    manifest_hash:       str,
    runner_sha:          str,
    counts:              Dict[str, int],
    theta_record:        Dict[str, object],
    verses:              List[Tuple[int, str]],
    observed_corpus_sha: str,
) -> Dict[str, object]:
    """
    Assemble a validator-compatible boundary record.

    The six required schema fields are at top level with exact names from
    ARTEFACT_SCHEMAS in scar_validator_v1_0_P27_T2.py.
    All LCR provenance is under lcr_provenance (validator ignores unknown fields).
    """
    run_id = RUN_ID_PRIMARY if mode == "primary" else RUN_ID_RERUN

    # Normalised blob SHA — from the same verse list as counts (single parse).
    normed_blob     = "\n".join(normalise(t) for _, t in verses)
    normed_blob_sha = sha256_string(normed_blob)

    return {
        # ── REQUIRED SCHEMA FIELDS ────────────────────────────────────────────
        # Exact names from ARTEFACT_SCHEMAS["EXECUTION_BOUNDARY.lock.json"].
        # All required=True. Do not rename or nest.

        "run_id":          run_id,
        "sealed_at":       time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "artefact_hashes": artefact_hashes,
        "environment": {
            "python_version":     sys.version,
            "platform":           platform.platform(),
            "machine":            platform.machine(),
            "processor":          platform.processor(),
            "hostname":           platform.node(),
            "hostname_role_note": (
                "Same hostname across both runs suggests same device. "
                "Different hostname is not by itself a determinism failure."
            ),
            # V5-M1: hash seed — typically unset on Pydroid 3 but recorded
            # for completeness; removes hostile-auditor edge case.
            "pythonhashseed":     os.environ.get("PYTHONHASHSEED", ""),
            # V5-M2: resolved paths recorded so auditor can verify provenance
            # without reconstructing the path model.
            "run_root":           run_root,
            "corpus_path":        corpus_path,
            "manifest_path":      manifest_path,
        },
        "validator_hash":  RUNNER_IDENTITY["validator_hash"],
        "manifest_hash":   manifest_hash,

        # ── SUPPLEMENTARY PROVENANCE (not schema-gated) ───────────────────────

        "boundary_role":              mode,
        "schema_version":             "1.0",
        # Fields expected to differ across runs — for auditor / diff tools.
        "determinism_excluded_fields": ["sealed_at", "run_id"],
        # Runner identity (Class B check R-PR-09 / P18 in validator).
        "runner_hash":                runner_sha,

        "lcr_provenance": {
            "framework":                   RUNNER_IDENTITY["framework"],
            "author":                      RUNNER_IDENTITY["author"],
            "year":                        RUNNER_IDENTITY["year"],
            "profile":                     RUNNER_IDENTITY["profile"],
            "surah":                       SURAH_NUMBER,
            "verse_count":                 len(verses),
            # V5-M3: both expected and observed corpus SHA side by side.
            "corpus_sha256_expected":      RUNNER_IDENTITY["corpus_sha256"],
            "corpus_sha256_observed":      observed_corpus_sha,
            "scar_schema_authority":       RUNNER_IDENTITY["scar_schema_authority"],
            "canonical_authority_doc_sha": RUNNER_IDENTITY["canonical_authority_doc_sha"],
            "sealed_pack_sha256":          RUNNER_IDENTITY["sealed_pack_sha256"],
            "null_samples":                RUNNER_IDENTITY["null_samples"],
            "seed":                        RUNNER_IDENTITY["seed"],
            "alpha":                       RUNNER_IDENTITY["alpha"],
            "fdr":                         RUNNER_IDENTITY["fdr"],
            "normalised_blob_sha256":      normed_blob_sha,
            "gai":                         "line-1",
            "normalisation_pipeline": [
                "unicode_NFC",
                "strip_diacritics",
                "strip_tatweel",
                "ta_marbuta_to_ha",
                "alef_maqsura_to_ya",
                "ya_hamza_to_ya",
            ],
            "counts_observed":  counts,
            "counts_expected":  EXPECTED,
            "counts_match":     counts == EXPECTED,
            "theta":            theta_record,
            "p_value_bound":    P_VALUE_BOUND,
            "kappa_L":          KAPPA_L_SEALED,
            "divisibility": {
                "total_798_div_7":   EXPECTED["total"] % 7  == 0,
                "total_798_div_19":  EXPECTED["total"] % 19 == 0,
                "ya_343_is_7_cubed": EXPECTED["ya"] == 7 ** 3,
            },
        },
    }


def seal_boundary(boundary: Dict[str, object], output_path: str) -> str:
    """
    Write the boundary to disc and return the SHA-256 of the encoded bytes.
    Binary write mode — no EOL translation.
    Hashes the exact encoded bytes object written (not a separate re-read).
    """
    payload = json.dumps(boundary, ensure_ascii=False, indent=2, sort_keys=True)
    encoded = payload.encode("utf-8")
    with open(output_path, "wb") as fh:
        fh.write(encoded)
    return sha256_bytes(encoded)


# ============================================================================
# 9.  MAIN
# ============================================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description="surah19_boundary_runner_v5.py — LCR/SCAR Danny Scott 2026"
    )
    parser.add_argument(
        "--mode", choices=["primary", "rerun"], required=True,
        help="primary → EXECUTION_BOUNDARY.lock.json  |  "
             "rerun → RERUN_BOUNDARY.lock.json"
    )
    parser.add_argument(
        "--run-dir", default=None,
        help="Run root directory (default: script directory)"
    )
    args = parser.parse_args()

    run_root      = resolve_run_root(args.run_dir)
    corpus_path   = join_run(run_root, CORPUS_FILENAME)
    manifest_path = join_run(run_root, MANIFEST_FILENAME)
    output_path   = join_run(run_root,
                             BOUNDARY_PRIMARY if args.mode == "primary"
                             else BOUNDARY_RERUN)
    run_id        = RUN_ID_PRIMARY if args.mode == "primary" else RUN_ID_RERUN

    print("=" * 70)
    print("  surah19_boundary_runner_v5.py — LCR / SCAR  Danny Scott 2026")
    print(f"  Mode     : {args.mode.upper()}")
    print(f"  Run root : {run_root}")
    print(f"  Output   : {output_path}")
    print("=" * 70)

    # [0] Runner self-hash
    runner_sha = sha256_file(os.path.abspath(__file__))
    print(f"\n[0/6]  Runner self-hash")
    print(f"  {runner_sha}")
    print(f"  ({os.path.abspath(__file__)})")

    # [1] Corpus SHA verification
    if not os.path.isfile(corpus_path):
        print(f"\n[FATAL] Corpus not found: {corpus_path}")
        sys.exit(1)
    print(f"\n[1/6]  Verifying corpus SHA-256 ...")
    observed_corpus_sha = sha256_file(corpus_path)
    if observed_corpus_sha != RUNNER_IDENTITY["corpus_sha256"]:
        print(f"  [FAIL]  Expected : {RUNNER_IDENTITY['corpus_sha256']}")
        print(f"          Observed : {observed_corpus_sha}")
        print("  Corpus does not match the sealed proof pack.  Aborting.")
        sys.exit(1)
    print(f"  [PASS]  {observed_corpus_sha}")

    # [2] Manifest hash
    if not os.path.isfile(manifest_path):
        print(f"\n[FATAL] Manifest not found: {manifest_path}")
        sys.exit(1)
    print(f"\n[2/6]  Hashing manifest ...")
    manifest_hash = sha256_file(manifest_path)
    print(f"  manifest_hash : {manifest_hash}")

    # [3] Artefact hashing
    print(f"\n[3/6]  Hashing run artefacts ...")
    artefact_hashes, missing = hash_artefacts(run_root)
    for name, h in artefact_hashes.items():
        print(f"  [OK]  {name}")
        print(f"        {h}")
    if missing:
        for name in missing:
            print(f"  [MISSING]  {name}")
        print(f"\n[FATAL] {len(missing)} artefact(s) missing from {run_root}")
        sys.exit(1)

    # [4] Parse and count
    print(f"\n[4/6]  Parsing Surah {SURAH_NUMBER} and counting letters ...")
    verses = parse_surah(corpus_path, SURAH_NUMBER)
    if not verses:
        print(f"  [FATAL] No verses found for Surah {SURAH_NUMBER}.")
        sys.exit(1)
    print(f"  Verses : {len(verses)}  (v{verses[0][0]}–v{verses[-1][0]})")

    counts    = count_letters(verses)
    all_match = True
    for key in ["kaf", "ha", "ya", "ayn", "sad", "total"]:
        obs    = counts[key]
        exp    = EXPECTED[key]
        status = "PASS" if obs == exp else "FAIL"
        if obs != exp:
            all_match = False
        print(f"  {key:5s}  observed={obs:4d}  expected={exp:4d}  [{status}]")
    if not all_match:
        print("\n[FATAL] Letter counts do not match sealed expected values.")
        sys.exit(1)
    print("  All counts verified.")

    # [5] Theta re-statement
    print(f"\n[5/6]  Re-stating sealed Theta ...")
    theta_record = restate_theta(counts["total"])
    print(f"  Theta      : {theta_record['theta_value']}")
    print(f"  Method     : {theta_record['theta_computation_method']}")
    print(f"  Consistent : {theta_record['observed_matches_expected']}")
    if not theta_record["observed_matches_expected"]:
        print("\n[FATAL] Observed total inconsistent with sealed expected total.")
        sys.exit(1)

    # [6] Build and seal boundary
    print(f"\n[6/6]  Sealing boundary ...")
    boundary = build_boundary(
        mode=args.mode,
        run_root=run_root,
        corpus_path=corpus_path,
        manifest_path=manifest_path,
        artefact_hashes=artefact_hashes,
        manifest_hash=manifest_hash,
        runner_sha=runner_sha,
        counts=counts,
        theta_record=theta_record,
        verses=verses,
        observed_corpus_sha=observed_corpus_sha,
    )
    boundary_sha = seal_boundary(boundary, output_path)
    print(f"  Written      : {output_path}")
    print(f"  Boundary SHA : {boundary_sha}")

    # Summary
    print("\n" + "=" * 70)
    print(f"  BOUNDARY SEALED  [{args.mode.upper()}]  run_id={run_id}")
    print("=" * 70)
    print(f"  kaf={counts['kaf']}  ha={counts['ha']}  ya={counts['ya']}")
    print(f"  ayn={counts['ayn']}  sad={counts['sad']}  total={counts['total']}")
    print(f"  Theta={theta_record['theta_value']}  p<1e-6  kappa_L={KAPPA_L_SEALED}")
    print(f"  798 ÷  7 = {EXPECTED['total'] //  7}  "
          f"(exact: {EXPECTED['total'] %  7 == 0})")
    print(f"  798 ÷ 19 = {EXPECTED['total'] // 19}  "
          f"(exact: {EXPECTED['total'] % 19 == 0})")
    print(f"  ya=343 = 7³  (exact: {EXPECTED['ya'] == 7 ** 3})")
    print()
    if args.mode == "primary":
        print("  NEXT STEP:")
        print(f'  python surah19_boundary_runner_v5.py --mode rerun '
              f'--run-dir "{run_root}"')
    else:
        print("  NEXT STEP:")
        print(f'  python scar_validator_v1_0_P27_T2.py '
              f'"{manifest_path}" "{run_root}"')
    print("=" * 70)


if __name__ == "__main__":
    main()
